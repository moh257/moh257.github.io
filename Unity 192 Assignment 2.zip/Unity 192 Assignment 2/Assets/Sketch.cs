using UnityEngine;
using Pathfinding.Serialization.JsonFx;
using System.Collections;

public class Sketch : MonoBehaviour {

    public GameObject myPrefab;
	string _WebsiteURL = "http://moh257testing192.azurewebsites.net/tables/trellocardsmoh257?zumo-api-version=2.0.0";

    void Start () {
        string jsonResponse = Request.GET(_WebsiteURL);

        if (string.IsNullOrEmpty(jsonResponse))
        {
            return;
        }

        Product[] products = JsonReader.Deserialize<Product[]>(jsonResponse);
		Debug.Log (products.Length);
        int totalCubes = products.Length;
        int totalDistance = 4;
        int i = 0;
        foreach (Product product in products)
		{
			float perc = i / (float)totalCubes;
            i++;
            float x = perc * totalDistance;
            float y = 5.0f;
            float z = 0.0f;
            GameObject newCube = (GameObject)Instantiate(myPrefab, new Vector3( x, y, z), Quaternion.identity);
			newCube.GetComponent<mycubescript>().SetSize(.2f * (1.0f - perc)) ;
			newCube.GetComponent<mycubescript>().rotateSpeed = .3f + perc * 4.0f;
            newCube.GetComponentInChildren<TextMesh>().text = product.Card;

        }   


		foreach (Product product in products)
		{
			float perc = i / (float)totalCubes;
			i++;
			float x = 3.0f;
			float y = 8.0f;
			float z = 2.0f;
			GameObject newCube = (GameObject)Instantiate(myPrefab, new Vector3( x, y, z), Quaternion.identity);
			newCube.GetComponent<mycubescript>().SetSize(.2f * (1.0f - perc)) ;
			newCube.GetComponent<mycubescript>().rotateSpeed = .1f + perc * .5f;
			newCube.GetComponentInChildren<TextMesh>().text = product.List;
		}    

		foreach (Product product in products)
		{
			float perc = i / (float)totalCubes;
			i++;
			float x = 3.0f;
			float y = 2.0f;
			float z = 2.0f;
			GameObject newCube = (GameObject)Instantiate(myPrefab, new Vector3( x, y, z), Quaternion.identity);
			newCube.GetComponent<mycubescript>().SetSize(.1f * (1.0f - perc)) ;
			newCube.GetComponent<mycubescript>().rotateSpeed = .1f + perc * .6f;
			newCube.GetComponentInChildren<TextMesh>().text = product.Date;
		}    


	}
	
	void Update () {
	
	}
}
